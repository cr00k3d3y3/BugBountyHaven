# Final Cleaned SQLiPlayground/app.py
from flask import Flask, request, render_template, g, make_response
import sqlite3, time
from pathlib import Path

app = Flask(__name__)
app.secret_key = 'ultrasecret'
DATABASE = 'data.db'

# DB Initialization

def initialize_db():
    if not Path(DATABASE).exists():
        db = sqlite3.connect(DATABASE)
        with open('schema.sql') as f:
            db.executescript(f.read())
        db.close()

initialize_db()

# DB Connection

def get_db():
    db = getattr(g, '_database', None)
    if db is None:
        db = g._database = sqlite3.connect(DATABASE)
    return db

@app.teardown_appcontext
def close_connection(exception):
    db = getattr(g, '_database', None)
    if db is not None:
        db.close()

# Log Requests

def log_attempt(endpoint, ip, payload):
    db = get_db()
    db.execute("INSERT INTO logs (endpoint, ip, payload) VALUES (?, ?, ?)", (endpoint, ip, payload))
    db.commit()

# Routes

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/classic', methods=['GET', 'POST'])
def classic():
    result, flag = '', ''
    hint = "Try injecting ' OR 1=1-- to bypass."
    if request.method == 'POST':
        name = request.form['name']
        log_attempt('/classic', request.remote_addr, name)
        query = f"SELECT * FROM users WHERE username = '{name}'"
        try:
            cur = get_db().cursor()
            cur.execute(query)
            data = cur.fetchall()
            result = data
            if any('admin' in str(row) for row in data):
                flag = '🎉 FLAG{classic_sqli_exploited}'
        except Exception as e:
            result = f"❌ Error: {e}"
    return render_template('classic.html', result=result, flag=flag, hint=hint)

@app.route('/union', methods=['GET', 'POST'])
def union():
    result, flag = '', ''
    hint = "Try UNION SELECT 1, 'admin'--"
    if request.method == 'POST':
        name = request.form['name']
        log_attempt('/union', request.remote_addr, name)
        query = f"SELECT id, username FROM users WHERE username = '{name}'"
        try:
            cur = get_db().cursor()
            cur.execute(query)
            result = cur.fetchall()
            if any('admin' in str(row) for row in result):
                flag = '🎉 FLAG{union_sqli_extracted}'
        except Exception as e:
            result = f"❌ Error: {e}"
    return render_template('union.html', result=result, flag=flag, hint=hint)

@app.route('/auth', methods=['GET', 'POST'])
def auth():
    result = ''
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        query = f"SELECT * FROM users WHERE username = '{username}' AND password = '{password}'"
        cur = get_db().cursor()
        cur.execute(query)
        user = cur.fetchone()
        if user:
            resp = make_response(render_template('auth.html', result=f"Welcome, {user[1]}!"))
            resp.set_cookie('auth', user[1])
            resp.set_cookie('role', user[4])
            return resp
        else:
            result = "Invalid credentials"
    return render_template('auth.html', result=result)

from datetime import datetime

# Add to app.py (email alert config and review logging setup)
import smtplib
from email.mime.text import MIMEText
from datetime import datetime

EMAIL_SENDER = 'alert@bbhlab.local'
EMAIL_RECEIVER = 'ded3y3@proton.me'
SMTP_SERVER = 'localhost'

# Email alert function
def send_alert(subject, body):
    try:
        msg = MIMEText(body)
        msg['Subject'] = subject
        msg['From'] = EMAIL_SENDER
        msg['To'] = EMAIL_RECEIVER

        with smtplib.SMTP(SMTP_SERVER) as server:
            server.sendmail(EMAIL_SENDER, EMAIL_RECEIVER, msg.as_string())
    except Exception as e:
        print(f"[!] Failed to send email: {e}")

@app.route('/moderate', methods=['GET', 'POST'])
def moderate():
    if request.cookies.get('role') != 'admin':
        return "Access Denied"

    db = get_db()
    cur = db.cursor()

    if request.method == 'POST':
        comment_id = request.form.get('id')
        action = request.form.get('action')
        mod = request.cookies.get('auth') or 'admin'
        new_status = 'approved' if action == 'approve' else 'flagged'
        cur.execute("UPDATE feedback SET status = ?, moderated_by = ? WHERE id = ?", (new_status, mod, comment_id))
        db.commit()

    cur.execute("SELECT id, comment, status, moderated_by FROM feedback ORDER BY id DESC")
    comments = cur.fetchall()
    return render_template("moderate.html", comments=comments)


@app.route('/reviewlog')
def review_log():
    cur = get_db().cursor()
    cur.execute("SELECT id, endpoint, ip, payload, timestamp FROM logs WHERE endpoint='/moderate' ORDER BY timestamp DESC")
    entries = cur.fetchall()
    return render_template('reviewlog.html', entries=entries)



@app.route('/scoreboard')
def scoreboard():
    cur = get_db().cursor()
    cur.execute("SELECT username, challenge_name, timestamp FROM submissions ORDER BY timestamp DESC")
    rows = cur.fetchall()
    return render_template('scoreboard.html', rows=rows)

@app.route('/feedback', methods=['GET', 'POST'])
def feedback():
    db = get_db()
    cur = db.cursor()
    
    if request.method == 'POST':
        comment = request.form.get('comment', '').strip()
        if comment:
            cur.execute("INSERT INTO feedback (comment) VALUES (?)", (comment,))
            db.commit()

    cur.execute("SELECT id, comment FROM feedback ORDER BY id DESC")
    rows = cur.fetchall()
    return render_template('feedback.html', rows=rows)


@app.route('/logs')
def view_logs():
    cur = get_db().cursor()
    cur.execute("SELECT endpoint, ip, payload, timestamp FROM logs ORDER BY timestamp DESC")
    rows = cur.fetchall()
    return render_template('logs.html', rows=rows)


@app.route('/submit_flag', methods=['GET', 'POST'])
def submit_flag():
    result = ''
    if request.method == 'POST':
        username = request.form['username']
        submitted_flag = request.form['flag']
        cur = get_db().cursor()

        cur.execute("SELECT challenge_name FROM flags WHERE flag_value = ?", (submitted_flag,))
        row = cur.fetchone()
        if row:
            challenge = row[0]
            cur.execute("SELECT * FROM submissions WHERE flag_value = ? AND username = ?", (submitted_flag, username))
            if cur.fetchone():
                result = "❗️ Flag already submitted."
            else:
                cur.execute("INSERT INTO submissions (username, flag_value, challenge_name, stars) VALUES (?, ?, ?, ?)",
                            (username, submitted_flag, challenge, 1))
                get_db().commit()
                result = f"✅ Flag accepted for challenge: {challenge}"
        else:
            result = "❌ Invalid flag."
    return render_template('submit_flag.html', result=result)



@app.route('/leak', methods=['GET', 'POST'])
def leak():
    result, flag = '', ''
    hint = "Leak SESSIONID=admin_ID by trying admin, guest, etc."
    if request.method == 'POST':
        user = request.form['user']
        log_attempt('/leak', request.remote_addr, user)
        query = f"SELECT * FROM users WHERE username = '{user}'"
        cur = get_db().cursor()
        try:
            cur.execute(query)
            row = cur.fetchone()
            if row:
                result = f"SESSIONID=admin_{row[0]}"
                if row[1] == 'admin':
                    flag = '🎉 FLAG{session_hijack}'
            else:
                result = "❌ No user found."
        except Exception as e:
            result = f"❌ Error: {e}"
    return render_template('leak.html', result=result, hint=hint, flag=flag)

@app.route('/admin')
def admin():
    if request.cookies.get('role') == 'admin':
        return render_template('flag.html', flag='FLAG{admin_area_access}')
    return "Access Denied"

@app.route('/campaign')
def campaign():
    cur = get_db().cursor()
    cur.execute("SELECT * FROM challenges")
    challenges = cur.fetchall()

    username = request.cookies.get('auth') or 'anonymous'
    cur.execute("SELECT flag_value, stars FROM submissions WHERE username = ?", (username,))
    found = {row[0]: row[1] for row in cur.fetchall()}

    progress = []
    for ch in challenges:
        flag_value = ch[4]
        stars = found.get(flag_value, 0)
        status = '✅ Solved' if stars else '❌ Unsolved'
        progress.append((ch[1], ch[2], ch[3], status, ch[5], stars))

    return render_template("campaign.html", progress=progress)

@app.route('/blind', methods=['GET', 'POST'])
def blind():
    result = ''
    hint = 'Try comparing known true and false conditions like: AND 1=1-- vs AND 1=0--'
    if request.method == 'POST':
        name = request.form['name']
        log_attempt('/blind', request.remote_addr, name)
        query = f"SELECT * FROM users WHERE username = '{name}'"
        try:
            cur = get_db().cursor()
            cur.execute(query)
            data = cur.fetchall()
            result = "✅ User exists (True)" if data else "❌ No match (False)"
        except:
            result = "❌ Query Error"
    return render_template('blind.html', result=result, hint=hint)

@app.route('/time', methods=['GET', 'POST'])
def time_based():
    result = ''
    hint = 'Try sleep() inside a SQL condition like: OR IF(1=1, SLEEP(5), 0)--'
    if request.method == 'POST':
        name = request.form['name']
        log_attempt('/time', request.remote_addr, name)
        if 'sleep' in name.lower():
            time.sleep(5)
            result = "⏱ Delay detected — likely injectable"
        else:
            result = f"Processed input: {name}"
    return render_template('time.html', result=result, hint=hint)

@app.route('/stacked', methods=['GET', 'POST'])
def stacked():
    results = []
    hint = 'Try: SELECT 1; UPDATE users SET role=\'admin\' WHERE username=\'guest\';'
    flag = ''
    if request.method == 'POST':
        raw_input = request.form['sql']
        log_attempt('/stacked', request.remote_addr, raw_input)
        queries = [q.strip() for q in raw_input.strip().split(';') if q.strip()]
        db = get_db()
        cur = db.cursor()
        for q in queries:
            try:
                cur.execute(q)
                db.commit()
                try:
                    data = cur.fetchall()
                    results.append(data)
                    if any('admin' in str(d) for d in data):
                        flag = '🎉 FLAG{stacked_query_executed}'
                except:
                    results.append("✅ Executed")
            except Exception as e:
                results.append(f"❌ Error: {e}")
    return render_template('stacked.html', result=results, hint=hint, flag=flag)


@app.route('/robots.txt')
def robots():
    return (
        "User-agent: *\n"
        "Disallow: /admin/\n"
        "Disallow: /backup.zip\n"
        "Disallow: /debug.php\n"
        "Disallow: /admin/config.php\n"
        "Disallow: /secret_dashboard\n",
        200,
        {'Content-Type': 'text/plain'}
    )

@app.route('/secret_dashboard')
def secret_dashboard():
    username = request.cookies.get('auth') or 'anonymous'
    cur = get_db().cursor()
    cur.execute("SELECT * FROM submissions WHERE username = ? AND flag_value = ?", (username, 'FLAG{found_hidden_admin_panel}'))
    if not cur.fetchone():
        cur.execute("INSERT INTO submissions (username, flag_value, challenge_name) VALUES (?, ?, ?)",
                    (username, 'FLAG{found_hidden_admin_panel}', 'Recon - Hidden Admin Panel'))
        get_db().commit()
    return render_template('secret.html')

@app.route('/.git/HEAD')
def git_head():
    log_attempt('/.git/HEAD', request.remote_addr, 'git enum')
    return "ref: refs/heads/main", 200, {'Content-Type': 'text/plain'}

@app.route('/git-config')
def git_config():
    flag = ''
    hint = 'Check this page for secrets often exposed by developers.'
    content = """
    [core]
        repositoryformatversion = 0
        filemode = true
        bare = false
        logallrefupdates = true
    [remote "origin"]
        url = https://github.com/example/bbh-lab.git
        fetch = +refs/heads/*:refs/remotes/origin/*
    [user]
        name = devadmin
        email = admin@example.com
    """

    # simulate flag drop if accessed
    user = request.cookies.get('auth') or 'anonymous'
    db = get_db()
    cur = db.cursor()
    cur.execute("SELECT * FROM submissions WHERE flag_value = ? AND username = ?", ('FLAG{exposed_git_config}', user))
    if not cur.fetchone():
        cur.execute("INSERT INTO submissions (username, flag_value, challenge_name) VALUES (?, ?, ?)",
                    (user, 'FLAG{exposed_git_config}', 'Exposed Git Config'))
        db.commit()
        flag = '🎉 FLAG{exposed_git_config}'

    return render_template("git_config.html", content=content, flag=flag, hint=hint)

@app.route('/.env')
def dot_env():
    content = """APP_ENV=production
APP_DEBUG=false
DB_HOST=localhost
DB_USER=admin
DB_PASS=supersecret
SECRET_KEY=FLAG{env_file_exposed}"""
    return app.response_class(content, mimetype='text/plain')

@app.route('/.git/config')
def git_config_route():
    content = """[core]
    repositoryformatversion = 0
    filemode = true
    bare = false
    logallrefupdates = true
[remote "origin"]
    url = https://github.com/example/target-repo.git
[branch "main"]
    remote = origin
    merge = refs/heads/main

# FLAG{git_config_leakage_detected}
"""
    return app.response_class(content, mimetype='text/plain')

@app.route('/admin-panel', methods=['GET', 'POST'])
def admin_panel_exposed():
    if request.cookies.get('role') == 'admin':
        flag = '🎯 FLAG{admin_interface_exposed}'
        return render_template('flag.html', flag=flag)

    return "🔐 Forbidden: Admins only. This page should not be exposed.", 403

@app.route('/backup.zip')
def backup_zip():
    username = request.cookies.get('auth') or 'anonymous'
    flag_value = 'FLAG{backup_archive_exposed}'
    challenge_name = 'Exposed Backup File'

    log_attempt('/backup.zip', request.remote_addr, 'attempted zip file access')

    cur = get_db().cursor()
    cur.execute("SELECT * FROM submissions WHERE username = ? AND flag_value = ?", (username, flag_value))
    if not cur.fetchone():
        cur.execute("INSERT INTO submissions (username, flag_value, challenge_name) VALUES (?, ?, ?)",
                    (username, flag_value, challenge_name))
        get_db().commit()

    return '''
        <h2>📦 Simulated Backup Archive: backup.zip</h2>
        <p><strong>Contents:</strong></p>
        <ul>
          <li>index.php</li>
          <li>config.php</li>
          <li>data.db</li>
          <li>.env</li>
        </ul>
        <p><code>🎉 FLAG{backup_archive_exposed}</code></p>
    '''


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=80)
